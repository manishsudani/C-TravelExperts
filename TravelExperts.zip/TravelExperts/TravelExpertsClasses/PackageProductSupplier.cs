﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsClasses
{
    /*  
     * Date: January 2019
     * Author: Manish Sudani
     */

    public class PackageProductSupplier
    {
        public int PackageID { get; set; }
        public int ProductSupplierID { get; set; }
    }
}
